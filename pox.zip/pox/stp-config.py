from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.revent import *

def launch ():
    core.openflow.addListenerByName("ConnectionUp", _handle_ConnectionUp)
    
def _handle_ConnectionUp (event):
    msg = of.ofp_flow_mod()
    msg.actions.append(of.ofp_action_output(port = of.OFPP_FLOOD))
    event.connection.send(msg)

# References:
# https://medium.com/@deelaka.perera/simple-network-topology-using-mininet-and-installing-flow-rules-directly-on-controller-3ec61ca2b962
# https://github.com/noxrepo/pox-doc/blob/master/include/openflow.rst